#ifndef CLOUD_COMM_H_INCLUDED
#define CLOUD_COMM_H_INCLUDED


#define CLOUD_SEND_MESSAGE_DELAY 1  //set to 30 sec

void* send_msg_to_cloud(void *sockfd);

#endif
