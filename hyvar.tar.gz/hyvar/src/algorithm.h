
int suggest_gear(int *gear_suggested);
int suggest_brake(int *brake_suggested);
