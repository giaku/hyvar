#ifndef CARSPEC_H_INCLUDED
#define CARSPEC_H_INCLUDED


#include "Fiat500X_spec.h"



#endif