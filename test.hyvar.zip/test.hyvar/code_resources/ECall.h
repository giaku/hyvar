
#ifndef ECALL_H_
#define ECALL_H_

#include "../src/sc_types.h"
		
#ifdef __cplusplus
extern "C" { 
#endif 

/*! \file Header of the state machine 'eCall'.
*/

/*! Enumeration of all states */ 
typedef enum
{
	ECall_main_region_InitData,
	ECall_main_region_InitData_InitData_Init_eCall_data,
	ECall_main_region_InitData_InitData_Init_eraGlonass_data,
	ECall_main_region_SetGnssSystem,
	ECall_main_region_SetLanguage,
	ECall_main_region__112Call,
	ECall_main_region__final_,
	ECall_main_region_FormatMSD,
	ECall_main_region_FormatMSD_FormatMSD_encode_ecall_message,
	ECall_main_region_FormatMSD_FormatMSD_send_msd,
	ECall_main_region_FormatMSD_FormatMSD_play_prompt,
	ECall_main_region_init_ecallmessage,
	ECall_main_region_init_ecallmessage_InitEcallMessage_init_ecallmessage,
	ECall_main_region_ATB2init,
	ECall_last_state
} ECallStates;

/*! Type definition of the data structure for the ECallIfaceFunc interface scope. */
typedef struct
{
	sc_integer proxy;
	sc_integer buffer;
} ECallIfaceFunc;

/*! Type definition of the data structure for the ECallIfaceData interface scope. */
typedef struct
{
	sc_integer GNSS;
	sc_string Language;
} ECallIfaceData;


/*! Define dimension of the state configuration vector for orthogonal states. */
#define ECALL_MAX_ORTHOGONAL_STATES 1

/*! 
 * Type definition of the data structure for the ECall state machine.
 * This data structure has to be allocated by the client code. 
 */
typedef struct
{
	ECallStates stateConfVector[ECALL_MAX_ORTHOGONAL_STATES];
	sc_ushort stateConfVectorPosition; 
	
	ECallIfaceFunc ifaceFunc;
	ECallIfaceData ifaceData;
} ECall;

/*! Initializes the ECall state machine data structures. Must be called before first usage.*/
extern void eCall_init(ECall* handle);

/*! Activates the state machine */
extern void eCall_enter(ECall* handle);

/*! Deactivates the state machine */
extern void eCall_exit(ECall* handle);

/*! Performs a 'run to completion' step. */
extern void eCall_runCycle(ECall* handle);


/*! Gets the value of the variable 'proxy' that is defined in the interface scope 'Func'. */ 
extern sc_integer eCallIfaceFunc_get_proxy(const ECall* handle);
/*! Sets the value of the variable 'proxy' that is defined in the interface scope 'Func'. */ 
extern void eCallIfaceFunc_set_proxy(ECall* handle, sc_integer value);
/*! Gets the value of the variable 'buffer' that is defined in the interface scope 'Func'. */ 
extern sc_integer eCallIfaceFunc_get_buffer(const ECall* handle);
/*! Sets the value of the variable 'buffer' that is defined in the interface scope 'Func'. */ 
extern void eCallIfaceFunc_set_buffer(ECall* handle, sc_integer value);
/*! Gets the value of the variable 'GNSS' that is defined in the interface scope 'Data'. */ 
extern sc_integer eCallIfaceData_get_gNSS(const ECall* handle);
/*! Sets the value of the variable 'GNSS' that is defined in the interface scope 'Data'. */ 
extern void eCallIfaceData_set_gNSS(ECall* handle, sc_integer value);
/*! Gets the value of the variable 'Language' that is defined in the interface scope 'Data'. */ 
extern sc_string eCallIfaceData_get_language(const ECall* handle);
/*! Sets the value of the variable 'Language' that is defined in the interface scope 'Data'. */ 
extern void eCallIfaceData_set_language(ECall* handle, sc_string value);

/*!
 * Checks whether the state machine is active (until 2.4.1 this method was used for states).
 * A state machine is active if it was entered. It is inactive if it has not been entered at all or if it has been exited.
 */
extern sc_boolean eCall_isActive(const ECall* handle);

/*!
 * Checks if all active states are final. 
 * If there are no active states then the state machine is considered being inactive. In this case this method returns false.
 */
extern sc_boolean eCall_isFinal(const ECall* handle);

/*! Checks if the specified state is active (until 2.4.1 the used method for states was called isActive()). */
extern sc_boolean eCall_isStateActive(const ECall* handle, ECallStates state);

#ifdef __cplusplus
}
#endif 

#endif /* ECALL_H_ */
