
#include <stdlib.h>
#include <string.h>
#include "sc_types.h"
#include "ECall.h"
#include "ECallRequired.h"
/*! \file Implementation of the state machine 'eCall'
*/

/* prototypes of all internal functions */
static sc_boolean eCall_check_main_region_InitData_InitData_Init_eCall_data_tr0_tr0(const ECall* handle);
static sc_boolean eCall_check_main_region_InitData_InitData_Init_eraGlonass_data_tr0_tr0(const ECall* handle);
static sc_boolean eCall_check_main_region_SetGnssSystem_tr0_tr0(const ECall* handle);
static sc_boolean eCall_check_main_region_SetLanguage_tr0_tr0(const ECall* handle);
static sc_boolean eCall_check_main_region__112Call_tr0_tr0(const ECall* handle);
static sc_boolean eCall_check_main_region_FormatMSD_FormatMSD_encode_ecall_message_tr0_tr0(const ECall* handle);
static sc_boolean eCall_check_main_region_FormatMSD_FormatMSD_send_msd_tr0_tr0(const ECall* handle);
static sc_boolean eCall_check_main_region_FormatMSD_FormatMSD_play_prompt_tr0_tr0(const ECall* handle);
static sc_boolean eCall_check_main_region_init_ecallmessage_InitEcallMessage_init_ecallmessage_tr0_tr0(const ECall* handle);
static sc_boolean eCall_check_main_region_ATB2init_tr0_tr0(const ECall* handle);
static void eCall_effect_main_region_InitData_tr0(ECall* handle);
static void eCall_effect_main_region_InitData_InitData_Init_eCall_data_tr0(ECall* handle);
static void eCall_effect_main_region_InitData_InitData_Init_eraGlonass_data_tr0(ECall* handle);
static void eCall_effect_main_region_SetGnssSystem_tr0(ECall* handle);
static void eCall_effect_main_region_SetLanguage_tr0(ECall* handle);
static void eCall_effect_main_region__112Call_tr0(ECall* handle);
static void eCall_effect_main_region_FormatMSD_tr0(ECall* handle);
static void eCall_effect_main_region_FormatMSD_FormatMSD_encode_ecall_message_tr0(ECall* handle);
static void eCall_effect_main_region_FormatMSD_FormatMSD_send_msd_tr0(ECall* handle);
static void eCall_effect_main_region_FormatMSD_FormatMSD_play_prompt_tr0(ECall* handle);
static void eCall_effect_main_region_init_ecallmessage_tr0(ECall* handle);
static void eCall_effect_main_region_init_ecallmessage_InitEcallMessage_init_ecallmessage_tr0(ECall* handle);
static void eCall_effect_main_region_ATB2init_tr0(ECall* handle);
static void eCall_enact_main_region_InitData_InitData_Init_eCall_data(ECall* handle);
static void eCall_enact_main_region_InitData_InitData_Init_eraGlonass_data(ECall* handle);
static void eCall_enact_main_region_SetGnssSystem(ECall* handle);
static void eCall_enact_main_region_SetLanguage(ECall* handle);
static void eCall_enact_main_region__112Call(ECall* handle);
static void eCall_enact_main_region_FormatMSD_FormatMSD_encode_ecall_message(ECall* handle);
static void eCall_enact_main_region_FormatMSD_FormatMSD_send_msd(ECall* handle);
static void eCall_enact_main_region_FormatMSD_FormatMSD_play_prompt(ECall* handle);
static void eCall_enact_main_region_init_ecallmessage_InitEcallMessage_init_ecallmessage(ECall* handle);
static void eCall_enact_main_region_ATB2init(ECall* handle);
static void eCall_enseq_main_region_InitData_default(ECall* handle);
static void eCall_enseq_main_region_InitData_InitData_Init_eCall_data_default(ECall* handle);
static void eCall_enseq_main_region_InitData_InitData_Init_eraGlonass_data_default(ECall* handle);
static void eCall_enseq_main_region_SetGnssSystem_default(ECall* handle);
static void eCall_enseq_main_region_SetLanguage_default(ECall* handle);
static void eCall_enseq_main_region__112Call_default(ECall* handle);
static void eCall_enseq_main_region__final__default(ECall* handle);
static void eCall_enseq_main_region_FormatMSD_default(ECall* handle);
static void eCall_enseq_main_region_FormatMSD_FormatMSD_encode_ecall_message_default(ECall* handle);
static void eCall_enseq_main_region_FormatMSD_FormatMSD_send_msd_default(ECall* handle);
static void eCall_enseq_main_region_FormatMSD_FormatMSD_play_prompt_default(ECall* handle);
static void eCall_enseq_main_region_init_ecallmessage_default(ECall* handle);
static void eCall_enseq_main_region_init_ecallmessage_InitEcallMessage_init_ecallmessage_default(ECall* handle);
static void eCall_enseq_main_region_ATB2init_default(ECall* handle);
static void eCall_enseq_main_region_default(ECall* handle);
static void eCall_enseq_main_region_InitData_InitData_default(ECall* handle);
static void eCall_enseq_main_region_FormatMSD_FormatMSD_default(ECall* handle);
static void eCall_enseq_main_region_init_ecallmessage_InitEcallMessage_default(ECall* handle);
static void eCall_exseq_main_region_InitData(ECall* handle);
static void eCall_exseq_main_region_InitData_InitData_Init_eCall_data(ECall* handle);
static void eCall_exseq_main_region_InitData_InitData_Init_eraGlonass_data(ECall* handle);
static void eCall_exseq_main_region_SetGnssSystem(ECall* handle);
static void eCall_exseq_main_region_SetLanguage(ECall* handle);
static void eCall_exseq_main_region__112Call(ECall* handle);
static void eCall_exseq_main_region__final_(ECall* handle);
static void eCall_exseq_main_region_FormatMSD(ECall* handle);
static void eCall_exseq_main_region_FormatMSD_FormatMSD_encode_ecall_message(ECall* handle);
static void eCall_exseq_main_region_FormatMSD_FormatMSD_send_msd(ECall* handle);
static void eCall_exseq_main_region_FormatMSD_FormatMSD_play_prompt(ECall* handle);
static void eCall_exseq_main_region_init_ecallmessage(ECall* handle);
static void eCall_exseq_main_region_init_ecallmessage_InitEcallMessage_init_ecallmessage(ECall* handle);
static void eCall_exseq_main_region_ATB2init(ECall* handle);
static void eCall_exseq_main_region(ECall* handle);
static void eCall_exseq_main_region_InitData_InitData(ECall* handle);
static void eCall_exseq_main_region_FormatMSD_FormatMSD(ECall* handle);
static void eCall_exseq_main_region_init_ecallmessage_InitEcallMessage(ECall* handle);
static void eCall_react_main_region_InitData_InitData_Init_eCall_data(ECall* handle);
static void eCall_react_main_region_InitData_InitData_Init_eraGlonass_data(ECall* handle);
static void eCall_react_main_region_SetGnssSystem(ECall* handle);
static void eCall_react_main_region_SetLanguage(ECall* handle);
static void eCall_react_main_region__112Call(ECall* handle);
static void eCall_react_main_region__final_(ECall* handle);
static void eCall_react_main_region_FormatMSD_FormatMSD_encode_ecall_message(ECall* handle);
static void eCall_react_main_region_FormatMSD_FormatMSD_send_msd(ECall* handle);
static void eCall_react_main_region_FormatMSD_FormatMSD_play_prompt(ECall* handle);
static void eCall_react_main_region_init_ecallmessage_InitEcallMessage_init_ecallmessage(ECall* handle);
static void eCall_react_main_region_ATB2init(ECall* handle);
static void eCall_react_main_region__entry_Default(ECall* handle);
static void eCall_react_main_region_InitData_InitData__entry_Default(ECall* handle);
static void eCall_react_main_region_FormatMSD_FormatMSD__entry_Default(ECall* handle);
static void eCall_react_main_region_init_ecallmessage_InitEcallMessage__entry_Default(ECall* handle);
static void eCall_react_main_region_InitData_InitData__exit_Default(ECall* handle);
static void eCall_react_main_region_FormatMSD_FormatMSD__exit_Default(ECall* handle);
static void eCall_react_main_region_init_ecallmessage_InitEcallMessage__exit_Default(ECall* handle);
static void eCall_clearInEvents(ECall* handle);
static void eCall_clearOutEvents(ECall* handle);


void eCall_init(ECall* handle)
{
	sc_integer i;

	for (i = 0; i < ECALL_MAX_ORTHOGONAL_STATES; ++i)
	{
		handle->stateConfVector[i] = ECall_last_state;
	}
	
	
	handle->stateConfVectorPosition = 0;

	eCall_clearInEvents(handle);
	eCall_clearOutEvents(handle);

	/* Default init sequence for statechart eCall */
	handle->ifaceFunc.proxy = 0;
	handle->ifaceFunc.buffer = 0;
	handle->ifaceData.GNSS = 0;
	handle->ifaceData.Language = "";

}

void eCall_enter(ECall* handle)
{
	/* Default enter sequence for statechart eCall */
	eCall_enseq_main_region_default(handle);
}

void eCall_exit(ECall* handle)
{
	/* Default exit sequence for statechart eCall */
	eCall_exseq_main_region(handle);
}

sc_boolean eCall_isActive(const ECall* handle)
{
	sc_boolean result;
	if (handle->stateConfVector[0] != ECall_last_state)
	{
		result =  bool_true;
	}
	else
	{
		result = bool_false;
	}
	return result;
}

sc_boolean eCall_isFinal(const ECall* handle)
{
	return (handle->stateConfVector[0] == ECall_main_region__final_);

}

static void eCall_clearInEvents(ECall* handle)
{
}

static void eCall_clearOutEvents(ECall* handle)
{
}

void eCall_runCycle(ECall* handle)
{
	
	eCall_clearOutEvents(handle);
	
	for (handle->stateConfVectorPosition = 0;
		handle->stateConfVectorPosition < ECALL_MAX_ORTHOGONAL_STATES;
		handle->stateConfVectorPosition++)
		{
			
		switch (handle->stateConfVector[handle->stateConfVectorPosition])
		{
		case ECall_main_region_InitData_InitData_Init_eCall_data :
		{
			eCall_react_main_region_InitData_InitData_Init_eCall_data(handle);
			break;
		}
		case ECall_main_region_InitData_InitData_Init_eraGlonass_data :
		{
			eCall_react_main_region_InitData_InitData_Init_eraGlonass_data(handle);
			break;
		}
		case ECall_main_region_SetGnssSystem :
		{
			eCall_react_main_region_SetGnssSystem(handle);
			break;
		}
		case ECall_main_region_SetLanguage :
		{
			eCall_react_main_region_SetLanguage(handle);
			break;
		}
		case ECall_main_region__112Call :
		{
			eCall_react_main_region__112Call(handle);
			break;
		}
		case ECall_main_region__final_ :
		{
			eCall_react_main_region__final_(handle);
			break;
		}
		case ECall_main_region_FormatMSD_FormatMSD_encode_ecall_message :
		{
			eCall_react_main_region_FormatMSD_FormatMSD_encode_ecall_message(handle);
			break;
		}
		case ECall_main_region_FormatMSD_FormatMSD_send_msd :
		{
			eCall_react_main_region_FormatMSD_FormatMSD_send_msd(handle);
			break;
		}
		case ECall_main_region_FormatMSD_FormatMSD_play_prompt :
		{
			eCall_react_main_region_FormatMSD_FormatMSD_play_prompt(handle);
			break;
		}
		case ECall_main_region_init_ecallmessage_InitEcallMessage_init_ecallmessage :
		{
			eCall_react_main_region_init_ecallmessage_InitEcallMessage_init_ecallmessage(handle);
			break;
		}
		case ECall_main_region_ATB2init :
		{
			eCall_react_main_region_ATB2init(handle);
			break;
		}
		default:
			break;
		}
	}
	
	eCall_clearInEvents(handle);
}


sc_boolean eCall_isStateActive(const ECall* handle, ECallStates state)
{
	sc_boolean result = bool_false;
	switch (state)
	{
		case ECall_main_region_InitData :
			result = (sc_boolean) (handle->stateConfVector[0] >= ECall_main_region_InitData
				&& handle->stateConfVector[0] <= ECall_main_region_InitData_InitData_Init_eraGlonass_data);
			break;
		case ECall_main_region_InitData_InitData_Init_eCall_data :
			result = (sc_boolean) (handle->stateConfVector[0] == ECall_main_region_InitData_InitData_Init_eCall_data
			);
			break;
		case ECall_main_region_InitData_InitData_Init_eraGlonass_data :
			result = (sc_boolean) (handle->stateConfVector[0] == ECall_main_region_InitData_InitData_Init_eraGlonass_data
			);
			break;
		case ECall_main_region_SetGnssSystem :
			result = (sc_boolean) (handle->stateConfVector[0] == ECall_main_region_SetGnssSystem
			);
			break;
		case ECall_main_region_SetLanguage :
			result = (sc_boolean) (handle->stateConfVector[0] == ECall_main_region_SetLanguage
			);
			break;
		case ECall_main_region__112Call :
			result = (sc_boolean) (handle->stateConfVector[0] == ECall_main_region__112Call
			);
			break;
		case ECall_main_region__final_ :
			result = (sc_boolean) (handle->stateConfVector[0] == ECall_main_region__final_
			);
			break;
		case ECall_main_region_FormatMSD :
			result = (sc_boolean) (handle->stateConfVector[0] >= ECall_main_region_FormatMSD
				&& handle->stateConfVector[0] <= ECall_main_region_FormatMSD_FormatMSD_play_prompt);
			break;
		case ECall_main_region_FormatMSD_FormatMSD_encode_ecall_message :
			result = (sc_boolean) (handle->stateConfVector[0] == ECall_main_region_FormatMSD_FormatMSD_encode_ecall_message
			);
			break;
		case ECall_main_region_FormatMSD_FormatMSD_send_msd :
			result = (sc_boolean) (handle->stateConfVector[0] == ECall_main_region_FormatMSD_FormatMSD_send_msd
			);
			break;
		case ECall_main_region_FormatMSD_FormatMSD_play_prompt :
			result = (sc_boolean) (handle->stateConfVector[0] == ECall_main_region_FormatMSD_FormatMSD_play_prompt
			);
			break;
		case ECall_main_region_init_ecallmessage :
			result = (sc_boolean) (handle->stateConfVector[0] >= ECall_main_region_init_ecallmessage
				&& handle->stateConfVector[0] <= ECall_main_region_init_ecallmessage_InitEcallMessage_init_ecallmessage);
			break;
		case ECall_main_region_init_ecallmessage_InitEcallMessage_init_ecallmessage :
			result = (sc_boolean) (handle->stateConfVector[0] == ECall_main_region_init_ecallmessage_InitEcallMessage_init_ecallmessage
			);
			break;
		case ECall_main_region_ATB2init :
			result = (sc_boolean) (handle->stateConfVector[0] == ECall_main_region_ATB2init
			);
			break;
		default:
			result = bool_false;
			break;
	}
	return result;
}



sc_integer eCallIfaceFunc_get_proxy(const ECall* handle)
{
	return handle->ifaceFunc.proxy;
}
void eCallIfaceFunc_set_proxy(ECall* handle, sc_integer value)
{
	handle->ifaceFunc.proxy = value;
}
sc_integer eCallIfaceFunc_get_buffer(const ECall* handle)
{
	return handle->ifaceFunc.buffer;
}
void eCallIfaceFunc_set_buffer(ECall* handle, sc_integer value)
{
	handle->ifaceFunc.buffer = value;
}


sc_integer eCallIfaceData_get_gNSS(const ECall* handle)
{
	return handle->ifaceData.GNSS;
}
void eCallIfaceData_set_gNSS(ECall* handle, sc_integer value)
{
	handle->ifaceData.GNSS = value;
}
sc_string eCallIfaceData_get_language(const ECall* handle)
{
	return handle->ifaceData.Language;
}
void eCallIfaceData_set_language(ECall* handle, sc_string value)
{
	handle->ifaceData.Language = value;
}

/* implementations of all internal functions */

static sc_boolean eCall_check_main_region_InitData_InitData_Init_eCall_data_tr0_tr0(const ECall* handle)
{
	return bool_true;
}

static sc_boolean eCall_check_main_region_InitData_InitData_Init_eraGlonass_data_tr0_tr0(const ECall* handle)
{
	return bool_true;
}

static sc_boolean eCall_check_main_region_SetGnssSystem_tr0_tr0(const ECall* handle)
{
	return bool_true;
}

static sc_boolean eCall_check_main_region_SetLanguage_tr0_tr0(const ECall* handle)
{
	return bool_true;
}

static sc_boolean eCall_check_main_region__112Call_tr0_tr0(const ECall* handle)
{
	return bool_true;
}

static sc_boolean eCall_check_main_region_FormatMSD_FormatMSD_encode_ecall_message_tr0_tr0(const ECall* handle)
{
	return bool_true;
}

static sc_boolean eCall_check_main_region_FormatMSD_FormatMSD_send_msd_tr0_tr0(const ECall* handle)
{
	return bool_true;
}

static sc_boolean eCall_check_main_region_FormatMSD_FormatMSD_play_prompt_tr0_tr0(const ECall* handle)
{
	return bool_true;
}

static sc_boolean eCall_check_main_region_init_ecallmessage_InitEcallMessage_init_ecallmessage_tr0_tr0(const ECall* handle)
{
	return bool_true;
}

static sc_boolean eCall_check_main_region_ATB2init_tr0_tr0(const ECall* handle)
{
	return bool_true;
}

static void eCall_effect_main_region_InitData_tr0(ECall* handle)
{
	eCall_exseq_main_region_InitData(handle);
	eCall_enseq_main_region_FormatMSD_default(handle);
}

static void eCall_effect_main_region_InitData_InitData_Init_eCall_data_tr0(ECall* handle)
{
	eCall_exseq_main_region_InitData_InitData_Init_eCall_data(handle);
	eCall_react_main_region_InitData_InitData__exit_Default(handle);
}

static void eCall_effect_main_region_InitData_InitData_Init_eraGlonass_data_tr0(ECall* handle)
{
	eCall_exseq_main_region_InitData_InitData_Init_eraGlonass_data(handle);
	eCall_enseq_main_region_InitData_InitData_Init_eCall_data_default(handle);
}

static void eCall_effect_main_region_SetGnssSystem_tr0(ECall* handle)
{
	eCall_exseq_main_region_SetGnssSystem(handle);
	eCall_enseq_main_region_SetLanguage_default(handle);
}

static void eCall_effect_main_region_SetLanguage_tr0(ECall* handle)
{
	eCall_exseq_main_region_SetLanguage(handle);
	eCall_enseq_main_region_init_ecallmessage_default(handle);
}

static void eCall_effect_main_region__112Call_tr0(ECall* handle)
{
	eCall_exseq_main_region__112Call(handle);
	eCall_enseq_main_region__final__default(handle);
}

static void eCall_effect_main_region_FormatMSD_tr0(ECall* handle)
{
	eCall_exseq_main_region_FormatMSD(handle);
	eCall_enseq_main_region__112Call_default(handle);
}

static void eCall_effect_main_region_FormatMSD_FormatMSD_encode_ecall_message_tr0(ECall* handle)
{
	eCall_exseq_main_region_FormatMSD_FormatMSD_encode_ecall_message(handle);
	eCall_enseq_main_region_FormatMSD_FormatMSD_play_prompt_default(handle);
}

static void eCall_effect_main_region_FormatMSD_FormatMSD_send_msd_tr0(ECall* handle)
{
	eCall_exseq_main_region_FormatMSD_FormatMSD_send_msd(handle);
	eCall_react_main_region_FormatMSD_FormatMSD__exit_Default(handle);
}

static void eCall_effect_main_region_FormatMSD_FormatMSD_play_prompt_tr0(ECall* handle)
{
	eCall_exseq_main_region_FormatMSD_FormatMSD_play_prompt(handle);
	eCall_enseq_main_region_FormatMSD_FormatMSD_send_msd_default(handle);
}

static void eCall_effect_main_region_init_ecallmessage_tr0(ECall* handle)
{
	eCall_exseq_main_region_init_ecallmessage(handle);
	eCall_enseq_main_region_InitData_default(handle);
}

static void eCall_effect_main_region_init_ecallmessage_InitEcallMessage_init_ecallmessage_tr0(ECall* handle)
{
	eCall_exseq_main_region_init_ecallmessage_InitEcallMessage_init_ecallmessage(handle);
	eCall_react_main_region_init_ecallmessage_InitEcallMessage__exit_Default(handle);
}

static void eCall_effect_main_region_ATB2init_tr0(ECall* handle)
{
	eCall_exseq_main_region_ATB2init(handle);
	eCall_enseq_main_region_SetGnssSystem_default(handle);
}

/* Entry action for state 'Init_eCall_data'. */
static void eCall_enact_main_region_InitData_InitData_Init_eCall_data(ECall* handle)
{
	/* Entry action for state 'Init_eCall_data'. */
	eCallIfaceFunc_init_eCall_data(handle);
}

/* Entry action for state 'Init_eraGlonass_data'. */
static void eCall_enact_main_region_InitData_InitData_Init_eraGlonass_data(ECall* handle)
{
	/* Entry action for state 'Init_eraGlonass_data'. */
	eCallIfaceFunc_init_eraGlonass_data(handle);
}

/* Entry action for state 'SetGnssSystem'. */
static void eCall_enact_main_region_SetGnssSystem(ECall* handle)
{
	/* Entry action for state 'SetGnssSystem'. */
	handle->ifaceData.GNSS = 1;
	eCallIfaceFunc_setGnssSystem(handle);
}

/* Entry action for state 'SetLanguage'. */
static void eCall_enact_main_region_SetLanguage(ECall* handle)
{
	/* Entry action for state 'SetLanguage'. */
	handle->ifaceData.Language = "German";
	eCallIfaceFunc_setLanguage(handle);
}

/* Entry action for state '112Call'. */
static void eCall_enact_main_region__112Call(ECall* handle)
{
	/* Entry action for state '112Call'. */
	eCallIfaceFunc_emergencyCall(handle);
}

/* Entry action for state 'encode_ecall_message'. */
static void eCall_enact_main_region_FormatMSD_FormatMSD_encode_ecall_message(ECall* handle)
{
	/* Entry action for state 'encode_ecall_message'. */
	eCallIfaceFunc_encode_ecallmessage(handle);
}

/* Entry action for state 'send_msd'. */
static void eCall_enact_main_region_FormatMSD_FormatMSD_send_msd(ECall* handle)
{
	/* Entry action for state 'send_msd'. */
	eCallIfaceFunc_send_msd(handle);
}

/* Entry action for state 'play_prompt'. */
static void eCall_enact_main_region_FormatMSD_FormatMSD_play_prompt(ECall* handle)
{
	/* Entry action for state 'play_prompt'. */
	eCallIfaceFunc_play_prompt(handle);
}

/* Entry action for state 'init_ecallmessage'. */
static void eCall_enact_main_region_init_ecallmessage_InitEcallMessage_init_ecallmessage(ECall* handle)
{
	/* Entry action for state 'init_ecallmessage'. */
	eCallIfaceFunc_init_ecallmessage(handle);
}

/* Entry action for state 'ATB2init'. */
static void eCall_enact_main_region_ATB2init(ECall* handle)
{
	/* Entry action for state 'ATB2init'. */
	eCallIfaceFunc_aTB2init(handle);
}

/* 'default' enter sequence for state InitData */
static void eCall_enseq_main_region_InitData_default(ECall* handle)
{
	/* 'default' enter sequence for state InitData */
	eCall_enseq_main_region_InitData_InitData_default(handle);
}

/* 'default' enter sequence for state Init_eCall_data */
static void eCall_enseq_main_region_InitData_InitData_Init_eCall_data_default(ECall* handle)
{
	/* 'default' enter sequence for state Init_eCall_data */
	eCall_enact_main_region_InitData_InitData_Init_eCall_data(handle);
	handle->stateConfVector[0] = ECall_main_region_InitData_InitData_Init_eCall_data;
	handle->stateConfVectorPosition = 0;
}

/* 'default' enter sequence for state Init_eraGlonass_data */
static void eCall_enseq_main_region_InitData_InitData_Init_eraGlonass_data_default(ECall* handle)
{
	/* 'default' enter sequence for state Init_eraGlonass_data */
	eCall_enact_main_region_InitData_InitData_Init_eraGlonass_data(handle);
	handle->stateConfVector[0] = ECall_main_region_InitData_InitData_Init_eraGlonass_data;
	handle->stateConfVectorPosition = 0;
}

/* 'default' enter sequence for state SetGnssSystem */
static void eCall_enseq_main_region_SetGnssSystem_default(ECall* handle)
{
	/* 'default' enter sequence for state SetGnssSystem */
	eCall_enact_main_region_SetGnssSystem(handle);
	handle->stateConfVector[0] = ECall_main_region_SetGnssSystem;
	handle->stateConfVectorPosition = 0;
}

/* 'default' enter sequence for state SetLanguage */
static void eCall_enseq_main_region_SetLanguage_default(ECall* handle)
{
	/* 'default' enter sequence for state SetLanguage */
	eCall_enact_main_region_SetLanguage(handle);
	handle->stateConfVector[0] = ECall_main_region_SetLanguage;
	handle->stateConfVectorPosition = 0;
}

/* 'default' enter sequence for state 112Call */
static void eCall_enseq_main_region__112Call_default(ECall* handle)
{
	/* 'default' enter sequence for state 112Call */
	eCall_enact_main_region__112Call(handle);
	handle->stateConfVector[0] = ECall_main_region__112Call;
	handle->stateConfVectorPosition = 0;
}

/* Default enter sequence for state null */
static void eCall_enseq_main_region__final__default(ECall* handle)
{
	/* Default enter sequence for state null */
	handle->stateConfVector[0] = ECall_main_region__final_;
	handle->stateConfVectorPosition = 0;
}

/* 'default' enter sequence for state FormatMSD */
static void eCall_enseq_main_region_FormatMSD_default(ECall* handle)
{
	/* 'default' enter sequence for state FormatMSD */
	eCall_enseq_main_region_FormatMSD_FormatMSD_default(handle);
}

/* 'default' enter sequence for state encode_ecall_message */
static void eCall_enseq_main_region_FormatMSD_FormatMSD_encode_ecall_message_default(ECall* handle)
{
	/* 'default' enter sequence for state encode_ecall_message */
	eCall_enact_main_region_FormatMSD_FormatMSD_encode_ecall_message(handle);
	handle->stateConfVector[0] = ECall_main_region_FormatMSD_FormatMSD_encode_ecall_message;
	handle->stateConfVectorPosition = 0;
}

/* 'default' enter sequence for state send_msd */
static void eCall_enseq_main_region_FormatMSD_FormatMSD_send_msd_default(ECall* handle)
{
	/* 'default' enter sequence for state send_msd */
	eCall_enact_main_region_FormatMSD_FormatMSD_send_msd(handle);
	handle->stateConfVector[0] = ECall_main_region_FormatMSD_FormatMSD_send_msd;
	handle->stateConfVectorPosition = 0;
}

/* 'default' enter sequence for state play_prompt */
static void eCall_enseq_main_region_FormatMSD_FormatMSD_play_prompt_default(ECall* handle)
{
	/* 'default' enter sequence for state play_prompt */
	eCall_enact_main_region_FormatMSD_FormatMSD_play_prompt(handle);
	handle->stateConfVector[0] = ECall_main_region_FormatMSD_FormatMSD_play_prompt;
	handle->stateConfVectorPosition = 0;
}

/* 'default' enter sequence for state init_ecallmessage */
static void eCall_enseq_main_region_init_ecallmessage_default(ECall* handle)
{
	/* 'default' enter sequence for state init_ecallmessage */
	eCall_enseq_main_region_init_ecallmessage_InitEcallMessage_default(handle);
}

/* 'default' enter sequence for state init_ecallmessage */
static void eCall_enseq_main_region_init_ecallmessage_InitEcallMessage_init_ecallmessage_default(ECall* handle)
{
	/* 'default' enter sequence for state init_ecallmessage */
	eCall_enact_main_region_init_ecallmessage_InitEcallMessage_init_ecallmessage(handle);
	handle->stateConfVector[0] = ECall_main_region_init_ecallmessage_InitEcallMessage_init_ecallmessage;
	handle->stateConfVectorPosition = 0;
}

/* 'default' enter sequence for state ATB2init */
static void eCall_enseq_main_region_ATB2init_default(ECall* handle)
{
	/* 'default' enter sequence for state ATB2init */
	eCall_enact_main_region_ATB2init(handle);
	handle->stateConfVector[0] = ECall_main_region_ATB2init;
	handle->stateConfVectorPosition = 0;
}

/* 'default' enter sequence for region main region */
static void eCall_enseq_main_region_default(ECall* handle)
{
	/* 'default' enter sequence for region main region */
	eCall_react_main_region__entry_Default(handle);
}

/* 'default' enter sequence for region InitData */
static void eCall_enseq_main_region_InitData_InitData_default(ECall* handle)
{
	/* 'default' enter sequence for region InitData */
	eCall_react_main_region_InitData_InitData__entry_Default(handle);
}

/* 'default' enter sequence for region FormatMSD */
static void eCall_enseq_main_region_FormatMSD_FormatMSD_default(ECall* handle)
{
	/* 'default' enter sequence for region FormatMSD */
	eCall_react_main_region_FormatMSD_FormatMSD__entry_Default(handle);
}

/* 'default' enter sequence for region InitEcallMessage */
static void eCall_enseq_main_region_init_ecallmessage_InitEcallMessage_default(ECall* handle)
{
	/* 'default' enter sequence for region InitEcallMessage */
	eCall_react_main_region_init_ecallmessage_InitEcallMessage__entry_Default(handle);
}

/* Default exit sequence for state InitData */
static void eCall_exseq_main_region_InitData(ECall* handle)
{
	/* Default exit sequence for state InitData */
	eCall_exseq_main_region_InitData_InitData(handle);
}

/* Default exit sequence for state Init_eCall_data */
static void eCall_exseq_main_region_InitData_InitData_Init_eCall_data(ECall* handle)
{
	/* Default exit sequence for state Init_eCall_data */
	handle->stateConfVector[0] = ECall_last_state;
	handle->stateConfVectorPosition = 0;
}

/* Default exit sequence for state Init_eraGlonass_data */
static void eCall_exseq_main_region_InitData_InitData_Init_eraGlonass_data(ECall* handle)
{
	/* Default exit sequence for state Init_eraGlonass_data */
	handle->stateConfVector[0] = ECall_last_state;
	handle->stateConfVectorPosition = 0;
}

/* Default exit sequence for state SetGnssSystem */
static void eCall_exseq_main_region_SetGnssSystem(ECall* handle)
{
	/* Default exit sequence for state SetGnssSystem */
	handle->stateConfVector[0] = ECall_last_state;
	handle->stateConfVectorPosition = 0;
}

/* Default exit sequence for state SetLanguage */
static void eCall_exseq_main_region_SetLanguage(ECall* handle)
{
	/* Default exit sequence for state SetLanguage */
	handle->stateConfVector[0] = ECall_last_state;
	handle->stateConfVectorPosition = 0;
}

/* Default exit sequence for state 112Call */
static void eCall_exseq_main_region__112Call(ECall* handle)
{
	/* Default exit sequence for state 112Call */
	handle->stateConfVector[0] = ECall_last_state;
	handle->stateConfVectorPosition = 0;
}

/* Default exit sequence for final state. */
static void eCall_exseq_main_region__final_(ECall* handle)
{
	/* Default exit sequence for final state. */
	handle->stateConfVector[0] = ECall_last_state;
	handle->stateConfVectorPosition = 0;
}

/* Default exit sequence for state FormatMSD */
static void eCall_exseq_main_region_FormatMSD(ECall* handle)
{
	/* Default exit sequence for state FormatMSD */
	eCall_exseq_main_region_FormatMSD_FormatMSD(handle);
}

/* Default exit sequence for state encode_ecall_message */
static void eCall_exseq_main_region_FormatMSD_FormatMSD_encode_ecall_message(ECall* handle)
{
	/* Default exit sequence for state encode_ecall_message */
	handle->stateConfVector[0] = ECall_last_state;
	handle->stateConfVectorPosition = 0;
}

/* Default exit sequence for state send_msd */
static void eCall_exseq_main_region_FormatMSD_FormatMSD_send_msd(ECall* handle)
{
	/* Default exit sequence for state send_msd */
	handle->stateConfVector[0] = ECall_last_state;
	handle->stateConfVectorPosition = 0;
}

/* Default exit sequence for state play_prompt */
static void eCall_exseq_main_region_FormatMSD_FormatMSD_play_prompt(ECall* handle)
{
	/* Default exit sequence for state play_prompt */
	handle->stateConfVector[0] = ECall_last_state;
	handle->stateConfVectorPosition = 0;
}

/* Default exit sequence for state init_ecallmessage */
static void eCall_exseq_main_region_init_ecallmessage(ECall* handle)
{
	/* Default exit sequence for state init_ecallmessage */
	eCall_exseq_main_region_init_ecallmessage_InitEcallMessage(handle);
}

/* Default exit sequence for state init_ecallmessage */
static void eCall_exseq_main_region_init_ecallmessage_InitEcallMessage_init_ecallmessage(ECall* handle)
{
	/* Default exit sequence for state init_ecallmessage */
	handle->stateConfVector[0] = ECall_last_state;
	handle->stateConfVectorPosition = 0;
}

/* Default exit sequence for state ATB2init */
static void eCall_exseq_main_region_ATB2init(ECall* handle)
{
	/* Default exit sequence for state ATB2init */
	handle->stateConfVector[0] = ECall_last_state;
	handle->stateConfVectorPosition = 0;
}

/* Default exit sequence for region main region */
static void eCall_exseq_main_region(ECall* handle)
{
	/* Default exit sequence for region main region */
	/* Handle exit of all possible states (of eCall.main_region) at position 0... */
	switch(handle->stateConfVector[ 0 ])
	{
		case ECall_main_region_InitData_InitData_Init_eCall_data :
		{
			eCall_exseq_main_region_InitData_InitData_Init_eCall_data(handle);
			break;
		}
		case ECall_main_region_InitData_InitData_Init_eraGlonass_data :
		{
			eCall_exseq_main_region_InitData_InitData_Init_eraGlonass_data(handle);
			break;
		}
		case ECall_main_region_SetGnssSystem :
		{
			eCall_exseq_main_region_SetGnssSystem(handle);
			break;
		}
		case ECall_main_region_SetLanguage :
		{
			eCall_exseq_main_region_SetLanguage(handle);
			break;
		}
		case ECall_main_region__112Call :
		{
			eCall_exseq_main_region__112Call(handle);
			break;
		}
		case ECall_main_region__final_ :
		{
			eCall_exseq_main_region__final_(handle);
			break;
		}
		case ECall_main_region_FormatMSD_FormatMSD_encode_ecall_message :
		{
			eCall_exseq_main_region_FormatMSD_FormatMSD_encode_ecall_message(handle);
			break;
		}
		case ECall_main_region_FormatMSD_FormatMSD_send_msd :
		{
			eCall_exseq_main_region_FormatMSD_FormatMSD_send_msd(handle);
			break;
		}
		case ECall_main_region_FormatMSD_FormatMSD_play_prompt :
		{
			eCall_exseq_main_region_FormatMSD_FormatMSD_play_prompt(handle);
			break;
		}
		case ECall_main_region_init_ecallmessage_InitEcallMessage_init_ecallmessage :
		{
			eCall_exseq_main_region_init_ecallmessage_InitEcallMessage_init_ecallmessage(handle);
			break;
		}
		case ECall_main_region_ATB2init :
		{
			eCall_exseq_main_region_ATB2init(handle);
			break;
		}
		default: break;
	}
}

/* Default exit sequence for region InitData */
static void eCall_exseq_main_region_InitData_InitData(ECall* handle)
{
	/* Default exit sequence for region InitData */
	/* Handle exit of all possible states (of eCall.main_region.InitData.InitData) at position 0... */
	switch(handle->stateConfVector[ 0 ])
	{
		case ECall_main_region_InitData_InitData_Init_eCall_data :
		{
			eCall_exseq_main_region_InitData_InitData_Init_eCall_data(handle);
			break;
		}
		case ECall_main_region_InitData_InitData_Init_eraGlonass_data :
		{
			eCall_exseq_main_region_InitData_InitData_Init_eraGlonass_data(handle);
			break;
		}
		default: break;
	}
}

/* Default exit sequence for region FormatMSD */
static void eCall_exseq_main_region_FormatMSD_FormatMSD(ECall* handle)
{
	/* Default exit sequence for region FormatMSD */
	/* Handle exit of all possible states (of eCall.main_region.FormatMSD.FormatMSD) at position 0... */
	switch(handle->stateConfVector[ 0 ])
	{
		case ECall_main_region_FormatMSD_FormatMSD_encode_ecall_message :
		{
			eCall_exseq_main_region_FormatMSD_FormatMSD_encode_ecall_message(handle);
			break;
		}
		case ECall_main_region_FormatMSD_FormatMSD_send_msd :
		{
			eCall_exseq_main_region_FormatMSD_FormatMSD_send_msd(handle);
			break;
		}
		case ECall_main_region_FormatMSD_FormatMSD_play_prompt :
		{
			eCall_exseq_main_region_FormatMSD_FormatMSD_play_prompt(handle);
			break;
		}
		default: break;
	}
}

/* Default exit sequence for region InitEcallMessage */
static void eCall_exseq_main_region_init_ecallmessage_InitEcallMessage(ECall* handle)
{
	/* Default exit sequence for region InitEcallMessage */
	/* Handle exit of all possible states (of eCall.main_region.init_ecallmessage.InitEcallMessage) at position 0... */
	switch(handle->stateConfVector[ 0 ])
	{
		case ECall_main_region_init_ecallmessage_InitEcallMessage_init_ecallmessage :
		{
			eCall_exseq_main_region_init_ecallmessage_InitEcallMessage_init_ecallmessage(handle);
			break;
		}
		default: break;
	}
}

/* The reactions of state Init_eCall_data. */
static void eCall_react_main_region_InitData_InitData_Init_eCall_data(ECall* handle)
{
	/* The reactions of state Init_eCall_data. */
	eCall_effect_main_region_InitData_InitData_Init_eCall_data_tr0(handle);
}

/* The reactions of state Init_eraGlonass_data. */
static void eCall_react_main_region_InitData_InitData_Init_eraGlonass_data(ECall* handle)
{
	/* The reactions of state Init_eraGlonass_data. */
	eCall_effect_main_region_InitData_InitData_Init_eraGlonass_data_tr0(handle);
}

/* The reactions of state SetGnssSystem. */
static void eCall_react_main_region_SetGnssSystem(ECall* handle)
{
	/* The reactions of state SetGnssSystem. */
	eCall_effect_main_region_SetGnssSystem_tr0(handle);
}

/* The reactions of state SetLanguage. */
static void eCall_react_main_region_SetLanguage(ECall* handle)
{
	/* The reactions of state SetLanguage. */
	eCall_effect_main_region_SetLanguage_tr0(handle);
}

/* The reactions of state 112Call. */
static void eCall_react_main_region__112Call(ECall* handle)
{
	/* The reactions of state 112Call. */
	eCall_effect_main_region__112Call_tr0(handle);
}

/* The reactions of state null. */
static void eCall_react_main_region__final_(ECall* handle)
{
	/* The reactions of state null. */
}

/* The reactions of state encode_ecall_message. */
static void eCall_react_main_region_FormatMSD_FormatMSD_encode_ecall_message(ECall* handle)
{
	/* The reactions of state encode_ecall_message. */
	eCall_effect_main_region_FormatMSD_FormatMSD_encode_ecall_message_tr0(handle);
}

/* The reactions of state send_msd. */
static void eCall_react_main_region_FormatMSD_FormatMSD_send_msd(ECall* handle)
{
	/* The reactions of state send_msd. */
	eCall_effect_main_region_FormatMSD_FormatMSD_send_msd_tr0(handle);
}

/* The reactions of state play_prompt. */
static void eCall_react_main_region_FormatMSD_FormatMSD_play_prompt(ECall* handle)
{
	/* The reactions of state play_prompt. */
	eCall_effect_main_region_FormatMSD_FormatMSD_play_prompt_tr0(handle);
}

/* The reactions of state init_ecallmessage. */
static void eCall_react_main_region_init_ecallmessage_InitEcallMessage_init_ecallmessage(ECall* handle)
{
	/* The reactions of state init_ecallmessage. */
	eCall_effect_main_region_init_ecallmessage_InitEcallMessage_init_ecallmessage_tr0(handle);
}

/* The reactions of state ATB2init. */
static void eCall_react_main_region_ATB2init(ECall* handle)
{
	/* The reactions of state ATB2init. */
	eCall_effect_main_region_ATB2init_tr0(handle);
}

/* Default react sequence for initial entry  */
static void eCall_react_main_region__entry_Default(ECall* handle)
{
	/* Default react sequence for initial entry  */
	eCall_enseq_main_region_ATB2init_default(handle);
}

/* Default react sequence for initial entry  */
static void eCall_react_main_region_InitData_InitData__entry_Default(ECall* handle)
{
	/* Default react sequence for initial entry  */
	eCall_enseq_main_region_InitData_InitData_Init_eraGlonass_data_default(handle);
}

/* Default react sequence for initial entry  */
static void eCall_react_main_region_FormatMSD_FormatMSD__entry_Default(ECall* handle)
{
	/* Default react sequence for initial entry  */
	eCall_enseq_main_region_FormatMSD_FormatMSD_encode_ecall_message_default(handle);
}

/* Default react sequence for initial entry  */
static void eCall_react_main_region_init_ecallmessage_InitEcallMessage__entry_Default(ECall* handle)
{
	/* Default react sequence for initial entry  */
	eCall_enseq_main_region_init_ecallmessage_InitEcallMessage_init_ecallmessage_default(handle);
}

/* The reactions of exit default. */
static void eCall_react_main_region_InitData_InitData__exit_Default(ECall* handle)
{
	/* The reactions of exit default. */
	eCall_effect_main_region_InitData_tr0(handle);
}

/* The reactions of exit default. */
static void eCall_react_main_region_FormatMSD_FormatMSD__exit_Default(ECall* handle)
{
	/* The reactions of exit default. */
	eCall_effect_main_region_FormatMSD_tr0(handle);
}

/* The reactions of exit default. */
static void eCall_react_main_region_init_ecallmessage_InitEcallMessage__exit_Default(ECall* handle)
{
	/* The reactions of exit default. */
	eCall_effect_main_region_init_ecallmessage_tr0(handle);
}


